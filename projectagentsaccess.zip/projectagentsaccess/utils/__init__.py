# Agentic AI Learning Platform Utilities
