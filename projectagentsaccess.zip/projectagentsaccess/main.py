from app import app
import routes  # noqa: F401
